import java.util.ArrayList; 
public class Notificacion {
    public int tipo;
    public String mensaje;
    public int dia;
    public int mes;
    public int year; 
    public Notificacion() {
        super();
    } 
  private ArrayList<String> estadisticas = new ArrayList<>();

  public void agregarEstadistica(String estadistica) {
    estadisticas.add(estadistica);
  }

  public void mostrarEstadisticas() {
    System.out.println("\nEstadísticas:");
    for (String estadistica : estadisticas) {
    System.out.println(estadistica);
    }
  }
  public void mostrarLista(ArrayList<String> lista) {
       System.out.println("\nLista de estadísticas:");
       for (int i = 0; i < lista.size(); i++) {
           System.out.println((i + 1) + ". " + lista.get(i));
       }
   }
    public String mostrarnoti(int tipo, String mensaje, int dia, int mes, int year) {
      String m = ("Tipo: " + tipo+ "Mensaje: " + mensaje+"Fecha: " + dia + "/" + mes + "/" + year);
      return m; 
    }  
    public void guardarest() {
        // Código para guardar la notificación
    }
    public void mostrarEstadisticas(){
      ///Codigo
    }
    public void mostrarLista() {
      //Código
    }
}