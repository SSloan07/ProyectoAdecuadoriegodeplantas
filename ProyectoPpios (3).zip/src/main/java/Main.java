import java.util.ArrayList;
import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    Planta nplanty = new Planta();
    int [] lista= new int [2]; 
    int dia, mes, year; 
    int tem; 
    float ha;  
    float ho; 
    float la; 
    float lo;  
    float ta;  
    float tk; 
    boolean comparar, auxiliar; 
    String m=""; 
    String lisbym ;
    System.out.println("Escriba el día:");
    dia=teclado.nextInt(); 
    auxiliar=nplanty.com(dia);
    while (auxiliar==false){
       m=nplanty.comprobardia(dia, m);
       dia=nplanty.registrar_dia(); 
       auxiliar=nplanty.com(dia);
     }
     System.out.print("Escriba el mes: ");  
     mes=nplanty.registrar_mes(); 
     auxiliar=nplanty.com2(mes);
     while (auxiliar==false){
       m=nplanty.comprobarmes(mes, m);
       mes=nplanty.registrar_mes(); 
       auxiliar=nplanty.com2(mes);
     }
     System.out.print("Escriba el año: ");
     year=nplanty.registrar_year();
    int primeravez = nplanty.primeraVez();
    int tp = nplanty.registrar_tipo_de_planta();
    if (primeravez==1 || tp==4 ){
      tem =nplanty.registrartiemporegado(); 
      ha = nplanty.registrar_humact();
      ho = nplanty.registrar_humopt();
      la = nplanty.registrar_lumact();
      lo = nplanty.registrar_lumopt();
      ta = nplanty.registrar_tempact();
      tk = nplanty.registrar_tempopt();
    } else{
      if (tp==1){
        tem = 3;
        ha = nplanty.registrar_humact();
        ho = 60;
        la = nplanty.registrar_lumact();
        lo = 6; 
        ta = nplanty.registrar_tempact();
        tk = 23;
      } else{
        if (tp==2){
           tem = 2;
           ha = nplanty.registrar_humact();
           ho = 50;
           la = nplanty.registrar_lumact();
           lo = 5; 
           ta = nplanty.registrar_tempact();
           tk = 20; 
        } else{
          tem = 1;
          ha = nplanty.registrar_humact();
          ho = 15;
          la = nplanty.registrar_lumact();
          lo = 7; 
          ta = nplanty.registrar_tempact();
          tk = 30;
        }
      }
    }
    comparar=nplanty.comparar_cond_actyop(ta, tk, ha, ho, la, lo);
    m=nplanty.mostrar_evaluacioncondact(comparar, m);//solucionado 
    System.out.println(m); 
    if (comparar==false){
      m=nplanty.mostrartiemporegado(tem, m);
      System.out.println(m); 
    }
    lista= nplanty.crearlistdbym(lista, comparar);
    lisbym=nplanty.mostrarlista(lista);
    System.out.println(m); 
    Notificacion notificacion = new Notificacion();
    if (comparar) {
      m=notificacion.mostrarnoti(1, "Condiciones óptimas: Todas las condiciones son óptimas para el crecimiento de la planta.", dia, mes, year);
    } else {
      m=notificacion.mostrarnoti(2, "Alerta: Al menos una de las condiciones no es óptima para el crecimiento de la planta.", dia, mes, year);
    }
  }
}
