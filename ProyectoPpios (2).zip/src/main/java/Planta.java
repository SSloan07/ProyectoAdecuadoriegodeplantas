import java.util.ArrayList; 
import java.util.Scanner; 
public class Planta 
{
  public float temperatura_actual;
  public float temperatura_optima;
  public float humedad_actual;
  public float humedad_optima;
  public float luminosidad_actual;
  public float luminosidad_optima; 
  public int tiempo_regado;
  public int dia;
  public int mes;
  public int year;
  public int tipo_de_planta;
  public Planta (){
    super();
  }
  private ArrayList<String> estadisticas = new ArrayList<>();

  public void agregarEstadistica(String estadistica) {
    estadisticas.add(estadistica);
  }

  public void mostrarEstadisticas() {
    System.out.println("\nEstadísticas:");
    for (String estadistica : estadisticas) {
    System.out.println(estadistica);
    }
  }
  public int primeraVez() {
    Scanner teclado = new Scanner(System.in);
    int primeraVez;
    System.out.println("¿Es su primera vez en usar el programa?. Escriba 1 si lo es y 2 si no");
    primeraVez = teclado.nextInt();
    while (primeraVez > 2 || primeraVez < 1) {
      System.out.println("Número fuera de rango. Recuerde, 1 para sí, 2 para no");
      primeraVez = teclado.nextInt();
    }
    return primeraVez;
  }
   public void mostrarTiempoRegado(int tiempo) {
       System.out.println("Tiempo de riego recomendado: " + tiempo + " minutos");
   }

   public void mostrarLista(ArrayList<String> lista) {
       System.out.println("\nLista de estadísticas:");
       for (int i = 0; i < lista.size(); i++) {
           System.out.println((i + 1) + ". " + lista.get(i));
       }
   }

   public void analizar_datos() {
     // TODO implement me	
   }
   public boolean comparar_cond_actyop(float temperatura_actual, float temperatura_optima, float humedad_actual, float humedad_optima, float luminosidad_actual, float luminosidad_optima) {
     boolean So;
     if ((temperatura_actual == temperatura_optima) && (humedad_actual == humedad_optima) && (luminosidad_actual == luminosidad_optima)) {
       So = true;
     } else {
       So = false;
     }
     return So;
   }

   public int[] crearlistdbym(int [] array, boolean comparar) { 
     //Declaracion
     if (comparar==true){
       array[0]=array[0]+1; 
     } else{
       array[1]=array[1]+1;  
     }
     return array; 
   }
  
   public String mostrarlista(int [] array){
     String m=("Los dias buenos: "+array[0]+"---los dias malos : "+array[1]);
     return m; 
   }
   public void guardarhumopt(double humedad_optima) {
     // TODO implement me	
   }
   public void guardarlumopt(double luminosidad_optima) {
     // TODO implement me	
   }
   public void guardartempopt(double temperatura_optima) {
     // TODO implement me	
   }
   public String mostrartiemporegado(int tiempo_regado, String message) {
     message=(tiempo_regado+" minutos.");
     return message; 
   }
  public Boolean com (int dia){
    boolean aux=true;
    if (dia>31 || dia<1){
      aux=false; 
      return aux;  
    }
    return aux; 
  }
  public Boolean com2 (int mes){
    boolean aux=true;
    if (mes>12 || mes<1){
      aux=false; 
      return aux;  
    }
    return aux; 
  }
  public String comprobardia (int dia, String message){
    while (dia>31 || dia<1){
      message=("Día fuera de rango. Escribalo nuevamente"); 
      return message; 
    }
    return message;
  }
  public String comprobarmes (int mes, String message){
    while (mes>12 || mes<1){
       message=("Mes fuera de rango. Escribalo nuevamente"); 
       return message; 
     }
    return message; 
  }
   public String mostrar_evaluacioncondact(boolean c, String message) {
     if (c==true){
       message=("Sus condiciones son optimas"); 
     } else{
       message=("Sus condiciones NO son optimas. Por lo tanto la debe regar:  "); 
     }
     return message; 
   }
  public int registrar_dia() {
     Scanner teclado= new Scanner (System.in);  
     int dia=teclado.nextInt(); 
     return dia; 
   }
  public int registrar_mes() {
     Scanner teclado= new Scanner (System.in);  
     int mes=teclado.nextInt(); 
     return mes; 
   }
  public int registrar_year() {
     Scanner teclado= new Scanner (System.in);  
     int year=teclado.nextInt(); 
     return year; 
   }
   public int registrartiemporegado() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba el tiempo de regado. En minutos : "); 
     int tiempo_regado=teclado.nextInt(); 
     return tiempo_regado; 
   }
   public float registrar_humact() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la humedad actual. En medida metrica de porcentaje : "); 
     float registrar_humact=teclado.nextFloat(); 
     return registrar_humact; 
   }
   public float registrar_humopt() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la humedad optima. En medida metrica de porcentaje : "); 
     float registrar_humopt=teclado.nextFloat(); 
     return registrar_humopt; 
   }
   public float registrar_lumact () {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la luminosidad actual. En medida metrica de horas : "); 
     float registrar_lumact=teclado.nextFloat(); 
     return registrar_lumact; 
   }
   public float registrar_lumopt() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la luminosidad optima. En medida metrica de horas : ");
     float registrar_lumopt=teclado.nextFloat(); 
     return registrar_lumopt; 
   }
   public float registrar_tempact() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la temperatura actual. En medida metrica de °C :"); 
     float registrar_tempact=teclado.nextFloat(); 
     return registrar_tempact;
   }
   public float registrar_tempopt() {
     Scanner teclado= new Scanner (System.in); 
     System.out.print("Escriba la temperatura optima. En medida metrica de °C :"); 
     float registrar_tempopt=teclado.nextFloat(); 
     return registrar_tempopt;
   }
   public int registrar_tipo_de_planta() {
     Scanner teclado = new Scanner(System.in);
     int tipo;
     System.out.println("Perfecto, ahora seleccione su planta");
     System.out.println("1-----------------------Girasol");
     System.out.println("2-----------------------Rosa");
     System.out.println("3-----------------------Cactus");
     System.out.println("4-----------------------Ninguna de las anteriores");
     tipo = teclado.nextInt();
     while (tipo > 4 || tipo < 1) {
       System.out.println("Numero fuera de rango. Escriba nuevamente su numero. Recuerde, entre 1 y 4");
       tipo = teclado.nextInt();
     }
     return tipo;
   }
 }