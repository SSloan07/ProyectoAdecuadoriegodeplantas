public class Notificacion {
    public int tipo;
    public String mensaje;
    public int dia;
    public int mes;
    public int year; 
    public Notificacion() {
        super();
    } 
    public void mostrarnoti(int tipo, String mensaje, int dia, int mes, int year) {
        System.out.println("Tipo: " + tipo);
        System.out.println("Mensaje: " + mensaje);
        System.out.println("Fecha: " + dia + "/" + mes + "/" + year);
    }  public void guardarest() {
        // Código para guardar la notificación
    }
}